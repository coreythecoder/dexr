</section>
<footer id="footer" class="clearfix ">
    <div class="footer">
        <div class="container">
            <div class="footer-inner">
                <div class="row">
                    <div class="col-md-4">
                        <div class="footer-content">
                            <div class="logo-footer"><img id="logo-footer" src="https://static.dexr.io/assets/images/blue-logo-45.png" alt=""></div>
                            <p>Dexr connects you with more than 68 million targeted businesses & web site owners with full contact information.</p>
                            <div class="separator-2"></div>
                            <nav>
                                <ul class="nav nav-pills nav-stacked">
                                    <li><a target="_blank" href="/pricing">Pricing</a></li>
                                    <li><a href="https://app.dexr.io/login">Sign In</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="footer-content state-list">
                            <h2 class="title">Browse Our Directory</h2>
                            <div class="separator-2"></div>
                            <?php
                            $states = statesArray();
                            foreach ($states as $k => $v) {
                                echo "<div class='col-md-3 col-xs-6'><a href='/" . strtolower($k) . "'>" . $v . "</a></div>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="subfooter">
        <div class="container">
            <div class="subfooter-inner">
                <div class="row">
                    <div class="col-md-12">
                        <p class="text-center">Copyright © <?php echo date('Y'); ?> <a href="/">dexr.</a> All Rights Reserved | <a href="/opt-out" rel="nofollow">Opt-Out</a></p>                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/jquery.min.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/modernizr.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/waypoints/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/jquery.countTo.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script src="https://static.dexr.io/assets/themes/v4/plugins/jquery.parallax-1.1.3.js"></script>
<script src="https://static.dexr.io/assets/themes/v4/plugins/jquery.validate.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/owl-carousel/owl.carousel.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/jquery.browser.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/plugins/SmoothScroll.js"></script>
<script type="text/javascript" src="https://static.dexr.io/assets/themes/v4/js/template.js"></script>
<script>
    jQuery(document).ready(function () {
        jQuery("#checkout_modal").click(function () {
            window.GoogleAnalyticsObject = 'analytics';
            jQuery.getScript('//www.google-analytics.com/analytics.js', function () {
                analytics('create', 'UA-133857018-1', 'auto');
                analytics('send', 'event', 'download_btn', 'click');
            });

        });
        jQuery("#99_checkout_btn").click(function () {
            window.GoogleAnalyticsObject = 'analytics';
            jQuery.getScript('//www.google-analytics.com/analytics.js', function () {
                analytics('create', 'UA-133857018-1', 'auto');
                analytics('send', 'event', '99_checkout_btn', 'click');
            });

        });
        jQuery("#9_99_checkout_btn").click(function () {
            window.GoogleAnalyticsObject = 'analytics';
            jQuery.getScript('//www.google-analytics.com/analytics.js', function () {
                analytics('create', 'UA-133857018-1', 'auto');
                analytics('send', 'event', '9_99_checkout_btn', 'click');
            });

        });
        jQuery(".uncover_btn").click(function () {
            window.GoogleAnalyticsObject = 'analytics';
            jQuery.getScript('//www.google-analytics.com/analytics.js', function () {
                analytics('create', 'UA-133857018-1', 'auto');
                analytics('send', 'event', 'uncover_btn', 'click');
            });

        });

        jQuery("#99_checkout_btn").click(function () {
            jQuery("#step_1").slideUp();
            jQuery("#step_2").slideDown();
        });
        jQuery("#continue_btn").click(function () {

            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/


            var pass = true;

            var name = jQuery("#name-in").val();
            if (!name) {
                jQuery("#name-in").css("border-color", "red");
                pass = false;
            }
            var email = jQuery("#email-in").val();
            if (!email || !email.match(re)) {
                jQuery("#email-in").css("border-color", "red");
                pass = false;
            }            
            var passw = jQuery("#password-in").val();
            if (!passw) {
                jQuery("#password-in").css("border-color", "red");
                pass = false;
            }
            var cpass = jQuery("#cpassword-in").val();
            if (!cpass) {
                jQuery("#cpassword-in").css("border-color", "red");
                pass = false;
            }

            if (!pass) {
                //jQuery(".form-control").css("border-color", "red");
            } else {
                jQuery("#step_2").slideUp();
                jQuery("#step_3").slideDown();
            }

            jQuery(".form-control").on("keyup", function () {
                jQuery(this).css("border-color", "green");
            });


        });

    });
</script>
</body>
</html>
