#!C:\Python34\python.exe

import pymysql
import os as application
from berserker_resolver import Resolver

host="dexr-production-2.ci0hkmciekd6.us-east-2.rds.amazonaws.com"
port="3306"
user="dexrdb"
passwd="dexrdbpass"
db="ebdb"

def application(environ, start_response):
    conn = pymysql.connect(host=host, port=3306, user=user, passwd=passwd, db=db)

    cur = conn.cursor()

    cur.execute("SELECT domain_name FROM user_1_3526197866 LIMIT 50")

    domains = []

    if cur is not None:
        for row in cur:
            domains.append(row[0])
    else:
        response = b"cur is empty"

    conn.commit()
    cur.close()

    resolver = Resolver(www=True, www_combine=True, verbose=True, timeout=5, tries=2, threads=50)
    result = resolver.resolve(domains)

    activeDomains = []

    if result['success'] is not None:
        for d in result['success']:
            if d in domains:
                activeDomains.append(d)
    else:
        response = b"d is empty"

    response = ' '.join(result['error'])

    status = '200 OK'
    headers = [('Content-type', 'text/html')]

    start_response(status, headers)

    if response is None:
        return print("GRRRRRRRRRRRRRRRRRR")
    else:
        return [response]
    