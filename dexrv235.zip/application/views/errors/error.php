<h3>Error</h3>
<p><b>Error</b>: <?php echo $message ?>
</p><p><input type="button" value="Go Back" onclick="window.history.back()" class="btn btn-default btn-sm" /> </p>