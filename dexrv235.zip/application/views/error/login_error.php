<div class="container">
    <div class="row">
        <div class="col-md-5 center-block-e animated shake">

            <div class="login-page-header">
                Uh oh!

            </div>
            <div class="login-page text-center">
                <p><b>Didn't work.</b></p>
                <p><input type="button" value="Try Again" onclick="window.history.back()" class="btn btn-success btn-sm" /> </p>
            </div>

        </div>
    </div>
</div>