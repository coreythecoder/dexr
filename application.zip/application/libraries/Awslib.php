<?php

class Awslib {

    function Lib() {
        require $_SERVER['DOCUMENT_ROOT'] . '/aws/aws-autoloader.php';
        
    }

}
