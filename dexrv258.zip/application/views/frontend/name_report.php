<style>
    .background-image {
        position: fixed;
        left: 0;
        right: 0;
        z-index: -1;
        display: block;
        background-image: linear-gradient( rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3) ), url(/assets/images/domainimage.jpg);
        background-size: cover;
        width: 100%;
        height: 100%;
        min-height:1600px;
    }

</style>
<div class='background-image'></div>